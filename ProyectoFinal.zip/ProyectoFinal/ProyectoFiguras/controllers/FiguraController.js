// Dentro de controllers/FiguraController.js
import FiguraService from '../services/FiguraService.js';
class FiguraController{

    FiguraService = null
    //constructor
    constructor(){
        this.figuraService=new FiguraService();
        this.formularioCalcularArea=this.formularioCalcularArea.bind(this);
        this.calcularAreasFiguras=this.calcularAreaFiguras.bind(this);
    
    
    }
    
    
    
    //metodo de calcular area
    formularioCalcularArea(request,response){
    response.reder('area');

    }
    calcularAreaFiguras(request,response){
        const {figura,base,altura}=request.body;
        let resultado;
        if(figura==='rectangulo'){
            resultado=this.figuraService.calcularAreaRectangulo(base,altura);
        }else if (figura==='triangulo'){
            resultado=this.figuraService.calcularAreaTriangulo(base,altura);
        }
        response.render('area',{resultado});
    }
}
export default FiguraController;