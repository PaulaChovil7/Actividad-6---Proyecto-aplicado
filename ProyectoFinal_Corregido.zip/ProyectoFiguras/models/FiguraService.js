
class FiguraService {
    calcularAreaTrapecio(baseMayor = 0, baseMenor = 0, altura = 0) {
        return ((parseFloat(baseMayor) + parseFloat(baseMenor)) * parseFloat(altura)) / 2;
    }

    calcularPerimetroTrapecio(lado1, lado2, baseMayor, baseMenor) {
        return parseFloat(lado1) + parseFloat(lado2) + parseFloat(baseMayor) + parseFloat(baseMenor);
    }

    calcularAreaRombo(diagonalMayor = 0, diagonalMenor = 0) {
        return (parseFloat(diagonalMayor) * parseFloat(diagonalMenor)) / 2;
    }

    calcularPerimetroRombo(lado) {
        return 4 * parseFloat(lado);
    }

    calcularAreaPentagono(lado = 0, apotema = 0) {
        return (5 * parseFloat(lado) * parseFloat(apotema)) / 2;
    }

    calcularPerimetroPentagono(lado) {
        return 5 * parseFloat(lado);
    }
}

export default FiguraService;
