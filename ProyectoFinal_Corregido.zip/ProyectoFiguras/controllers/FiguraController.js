
import FiguraService from '../models/FiguraService.js';

class FiguraController {
    figuraService = null;

    constructor() {
        this.figuraService = new FiguraService();
        this.formularioCalcularArea = this.formularioCalcularArea.bind(this);
        this.calcularAreaFiguras = this.calcularAreaFiguras.bind(this);
        this.calcularPerimetroFiguras = this.calcularPerimetroFiguras.bind(this);
    }

    formularioCalcularArea(request, response) {
        response.render('area');
    }

    calcularAreaFiguras(request, response) {
        const { figura, ...valores } = request.body;
        let resultado;

        switch (figura) {
            case 'trapecio':
                resultado = this.figuraService.calcularAreaTrapecio(valores.baseMayor, valores.baseMenor, valores.altura);
                break;
            case 'rombo':
                resultado = this.figuraService.calcularAreaRombo(valores.diagonalMayor, valores.diagonalMenor);
                break;
            case 'pentagono':
                resultado = this.figuraService.calcularAreaPentagono(valores.lado, valores.apotema);
                break;
            default:
                resultado = 'Figura no válida';
        }

        response.render('area', { resultado });
    }

    calcularPerimetroFiguras(request, response) {
        const { figura, ...valores } = request.body;
        let resultado;

        switch (figura) {
            case 'trapecio':
                resultado = this.figuraService.calcularPerimetroTrapecio(valores.lado1, valores.lado2, valores.baseMayor, valores.baseMenor);
                break;
            case 'rombo':
                resultado = this.figuraService.calcularPerimetroRombo(valores.lado);
                break;
            case 'pentagono':
                resultado = this.figuraService.calcularPerimetroPentagono(valores.lado);
                break;
            default:
                resultado = 'Figura no válida';
        }

        response.render('area', { resultado });
    }
}

export default FiguraController;
